package com.malix.licensemanager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Purple,
    secondary = Cyan,
    background = Black,
    surface = DarkGray,
    onPrimary = TextPrimary,
    onSecondary = Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun MalixTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}