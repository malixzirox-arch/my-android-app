package com.malix.licensemanager.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val Purple = Color(0xFFB026FF)
val Cyan = Color(0xFF00E5FF)
val DarkGray = Color(0xFF121212)
val CardGray = Color(0xFF1E1E1E)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B0B0)