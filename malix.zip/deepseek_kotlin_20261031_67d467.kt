package com.malix.licensemanager.data

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.postgrest.Postgrest

val supabase: SupabaseClient by lazy {
    createSupabaseClient(
        supabaseUrl = "YOUR_SUPABASE_URL",      // Replace
        supabaseKey = "YOUR_SUPABASE_ANON_KEY"  // Replace
    ) {
        install(Auth)
        install(Postgrest)
        install(Functions)
    }
}