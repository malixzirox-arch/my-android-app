package com.malix.licensemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.malix.licensemanager.ui.screens.*
import com.malix.licensemanager.ui.theme.*
import com.malix.licensemanager.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MalixTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(viewModel: MainViewModel = viewModel()) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()

    if (!isLoggedIn) {
        LoginScreen(onLogin = { e, p -> viewModel.login(e, p) })
        return
    }

    val navController = rememberNavController()
    val items = listOf(
        Screen.Dashboard to Icons.Default.Dashboard,
        Screen.Apps to Icons.Default.Apps,
        Screen.Keys to Icons.Default.VpnKey,
        Screen.Devices to Icons.Default.Devices
    )

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = CardGray) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                items.forEach { (screen, icon) ->
                    NavigationBarItem(
                        icon = { Icon(icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan,
                            selectedTextColor = Cyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = Purple.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Dashboard.route) { DashboardScreen(viewModel) }
            composable(Screen.Apps.route) { AppsScreen(viewModel) }
            composable(Screen.Keys.route) { KeysScreen(viewModel) }
            composable(Screen.Devices.route) { DevicesScreen(viewModel) }
        }
    }

    // Show message snackbar
    val message by viewModel.message.collectAsState()
    if (message != null) {
        LaunchedEffect(message) {
            // Auto-clear after 3s (simple approach)
            kotlinx.coroutines.delay(3000)
            viewModel.clearMessage()
        }
    }
}

sealed class Screen(val route: String, val title: String) {
    data object Dashboard : Screen("dashboard", "لوحة التحكم")
    data object Apps : Screen("apps", "التطبيقات")
    data object Keys : Screen("keys", "المفاتيح")
    data object Devices : Screen("devices", "الأجهزة")
}