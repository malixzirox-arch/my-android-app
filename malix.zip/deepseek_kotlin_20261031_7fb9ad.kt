package com.malix.licensemanager.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class App(
    val id: String = "",
    @SerialName("app_name") val appName: String,
    @SerialName("app_identifier") val appIdentifier: String,
    @SerialName("created_at") val createdAt: String = ""
)

@Serializable
data class LicenseKey(
    val id: String = "",
    @SerialName("app_id") val appId: String,
    @SerialName("license_key") val licenseKey: String,
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("max_devices") val maxDevices: Int = 1,
    @SerialName("expires_at") val expiresAt: String? = null,
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("app_name") val appName: String? = null,
    @SerialName("active_devices") val activeDevices: Int = 0
)

@Serializable
data class Device(
    val id: String = "",
    @SerialName("license_key_id") val licenseKeyId: String,
    @SerialName("device_id") val deviceId: String,
    @SerialName("device_name") val deviceName: String? = null,
    @SerialName("activated_at") val activatedAt: String = "",
    @SerialName("is_active") val isActive: Boolean = true,
    @SerialName("license_key") val licenseKey: String? = null
)

@Serializable
data class DashboardStats(
    @SerialName("total_apps") val totalApps: Long = 0,
    @SerialName("total_keys") val totalKeys: Long = 0,
    @SerialName("active_keys") val activeKeys: Long = 0,
    @SerialName("total_devices") val totalDevices: Long = 0
)

@Serializable
data class ActivateRequest(
    @SerialName("license_key") val licenseKey: String,
    @SerialName("device_id") val deviceId: String,
    @SerialName("device_name") val deviceName: String? = null,
    @SerialName("app_identifier") val appIdentifier: String
)

@Serializable
data class ActivateResponse(
    val valid: Boolean,
    val message: String,
    @SerialName("license_id") val licenseId: String? = null,
    @SerialName("expires_at") val expiresAt: String? = null
)