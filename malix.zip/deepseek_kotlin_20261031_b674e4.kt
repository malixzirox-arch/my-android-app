package com.malix.licensemanager.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.malix.licensemanager.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val _isLoggedIn = MutableStateFlow(LicenseRepository.isLoggedIn())
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn

    private val _stats = MutableStateFlow(DashboardStats())
    val stats: StateFlow<DashboardStats> = _stats

    private val _apps = MutableStateFlow<List<App>>(emptyList())
    val apps: StateFlow<List<App>> = _apps

    private val _keys = MutableStateFlow<List<LicenseKey>>(emptyList())
    val keys: StateFlow<List<LicenseKey>> = _keys

    private val _devices = MutableStateFlow<List<Device>>(emptyList())
    val devices: StateFlow<List<Device>> = _devices

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun login(email: String, password: String) {
        viewModelScope.launch {
            LicenseRepository.login(email, password)
                .onSuccess { _isLoggedIn.value = true }
                .onFailure { _message.value = it.message ?: "فشل تسجيل الدخول" }
        }
    }

    fun logout() {
        viewModelScope.launch {
            LicenseRepository.logout()
            _isLoggedIn.value = false
        }
    }

    fun refreshAll() {
        viewModelScope.launch {
            try {
                _stats.value = LicenseRepository.getDashboardStats()
                _apps.value = LicenseRepository.getApps()
                _keys.value = LicenseRepository.getKeys()
                _devices.value = LicenseRepository.getDevices()
            } catch (e: Exception) {
                _message.value = e.message
            }
        }
    }

    fun createApp(name: String, identifier: String) {
        viewModelScope.launch {
            LicenseRepository.createApp(name, identifier)
                .onSuccess { refreshAll(); _message.value = "تمت إضافة التطبيق" }
                .onFailure { _message.value = it.message }
        }
    }

    fun deleteApp(id: String) {
        viewModelScope.launch {
            LicenseRepository.deleteApp(id)
                .onSuccess { refreshAll() }
                .onFailure { _message.value = it.message }
        }
    }

    fun generateKeys(appId: String, count: Int, maxDevices: Int, expiresAt: String?) {
        viewModelScope.launch {
            LicenseRepository.generateKeys(appId, count, maxDevices, expiresAt)
                .onSuccess { refreshAll(); _message.value = "تم إنشاء $count مفتاح" }
                .onFailure { _message.value = it.message }
        }
    }

    fun toggleKey(id: String, active: Boolean) {
        viewModelScope.launch {
            LicenseRepository.toggleKey(id, active)
                .onSuccess { refreshAll() }
                .onFailure { _message.value = it.message }
        }
    }

    fun deleteKey(id: String) {
        viewModelScope.launch {
            LicenseRepository.deleteKey(id)
                .onSuccess { refreshAll() }
                .onFailure { _message.value = it.message }
        }
    }

    fun deactivateDevice(id: String) {
        viewModelScope.launch {
            LicenseRepository.deactivateDevice(id)
                .onSuccess { refreshAll() }
                .onFailure { _message.value = it.message }
        }
    }

    fun clearMessage() { _message.value = null }
}