package com.malix.licensemanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.malix.licensemanager.ui.theme.*
import com.malix.licensemanager.viewmodel.MainViewModel

@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val stats by viewModel.stats.collectAsState()

    LaunchedEffect(Unit) { viewModel.refreshAll() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .padding(16.dp)
    ) {
        Text("لوحة التحكم", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(Modifier.height(24.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("التطبيقات", stats.totalApps.toString(), Purple, Modifier.weight(1f))
            StatCard("المفاتيح", stats.totalKeys.toString(), Cyan, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("نشطة", stats.activeKeys.toString(), Color(0xFF4CAF50), Modifier.weight(1f))
            StatCard("الأجهزة", stats.totalDevices.toString(), Color(0xFFFF9800), Modifier.weight(1f))
        }

        Spacer(Modifier.height(32.dp))
        Button(
            onClick = { viewModel.logout() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("تسجيل الخروج", color = TextPrimary)
        }
    }
}

@Composable
fun StatCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardGray)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text(value, fontSize = 32.sp, fontWeight = FontWeight.Bold, color = accent)
            Spacer(Modifier.height(4.dp))
            Text(title, fontSize = 14.sp, color = TextSecondary)
        }
    }
}