package com.malix.licensemanager.data

import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.functions.functions
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

object LicenseRepository {

    // ── Auth ──────────────────────────────────────────────
    suspend fun login(email: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun logout() = withContext(Dispatchers.IO) {
        supabase.auth.signOut()
    }

    fun isLoggedIn(): Boolean = supabase.auth.currentSessionOrNull() != null

    // ── Dashboard ─────────────────────────────────────────
    suspend fun getDashboardStats(): DashboardStats = withContext(Dispatchers.IO) {
        val apps = supabase.postgrest["apps"].select().decodeList<App>()
        val keys = supabase.postgrest["license_keys"].select().decodeList<LicenseKey>()
        val devices = supabase.postgrest["devices"].select().decodeList<Device>()
        DashboardStats(
            totalApps = apps.size.toLong(),
            totalKeys = keys.size.toLong(),
            activeKeys = keys.count { it.isActive }.toLong(),
            totalDevices = devices.count { it.isActive }.toLong()
        )
    }

    // ── Apps ──────────────────────────────────────────────
    suspend fun getApps(): List<App> = withContext(Dispatchers.IO) {
        supabase.postgrest["apps"].select()
            .order("created_at", Order.DESCENDING)
            .decodeList()
    }

    suspend fun createApp(name: String, identifier: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.postgrest["apps"].insert(
                App(appName = name, appIdentifier = identifier)
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteApp(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.postgrest["apps"].delete { filter { eq("id", id) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── License Keys ──────────────────────────────────────
    suspend fun getKeys(): List<LicenseKey> = withContext(Dispatchers.IO) {
        supabase.postgrest["license_keys"].select()
            .order("created_at", Order.DESCENDING)
            .decodeList()
    }

    suspend fun generateKeys(
        appId: String,
        count: Int,
        maxDevices: Int,
        expiresAt: String?
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val keys = (1..count).map {
                val raw = UUID.randomUUID().toString().replace("-", "").uppercase()
                "MALIX-${raw.chunked(4).joinToString("-")}"
            }
            val entities = keys.map { key ->
                LicenseKey(
                    appId = appId,
                    licenseKey = key,
                    maxDevices = maxDevices,
                    expiresAt = expiresAt,
                    isActive = true
                )
            }
            supabase.postgrest["license_keys"].insert(entities)
            Result.success(keys)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleKey(id: String, active: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.postgrest["license_keys"].update(
                { set("is_active", active) }
            ) { filter { eq("id", id) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteKey(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.postgrest["license_keys"].delete { filter { eq("id", id) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Devices ───────────────────────────────────────────
    suspend fun getDevices(): List<Device> = withContext(Dispatchers.IO) {
        supabase.postgrest["devices"].select()
            .order("activated_at", Order.DESCENDING)
            .decodeList()
    }

    suspend fun deactivateDevice(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            supabase.postgrest["devices"].update(
                { set("is_active", false) }
            ) { filter { eq("id", id) } }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Universal REST API (Edge Function) ───────────────
    suspend fun activateLicense(request: ActivateRequest): Result<ActivateResponse> =
        withContext(Dispatchers.IO) {
            try {
                val response = supabase.functions.invoke(
                    function = "license-api",
                    body = buildJsonObject {
                        put("action", "activate")
                        put("license_key", request.licenseKey)
                        put("device_id", request.deviceId)
                        put("device_name", request.deviceName ?: "")
                        put("app_identifier", request.appIdentifier)
                    }
                )
                val result = response.decodeAs<ActivateResponse>()
                Result.success(result)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun verifyLicense(licenseKey: String, appIdentifier: String): Result<ActivateResponse> =
        withContext(Dispatchers.IO) {
            try {
                val response = supabase.functions.invoke(
                    function = "license-api",
                    body = buildJsonObject {
                        put("action", "verify")
                        put("license_key", licenseKey)
                        put("app_identifier", appIdentifier)
                    }
                )
                val result = response.decodeAs<ActivateResponse>()
                Result.success(result)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}